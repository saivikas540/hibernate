package com.spring.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.UsesSunHttpServer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.dao.UserDao;
import com.spring.model.User;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	@Autowired
	private HttpSession session;
	
	@Autowired
	private UserDao dao;

	public void saveUser(User usr) {
		dao.saveUser(usr);
	}

	public List<User> findAllUsers() {
		return dao.findAllUsers();
	}

	public void deleteUserByName(String name) {
		dao.deleteUserByName(name);
	}

	public User findByName(String name) {
		return dao.findByName(name);
	}

	public void updateUser(User User) {
		dao.updateUser(User);
	}
	
	public boolean findUser(User usr) {
		return dao.findUser(usr);
	}



	
}
