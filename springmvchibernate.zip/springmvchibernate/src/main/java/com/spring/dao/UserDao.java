package com.spring.dao;

import java.util.List;

import com.spring.model.User;


public interface UserDao {
	void saveUser(User usr);
    
    List<User> findAllUsers();
     
    void deleteUserByName(String name);
     
    User findByName(String name);
     
    void updateUser(User usr);
    
    boolean findUser(User usr);
}
