package com.spring.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.spring.model.User;
import com.spring.service.UserService;
import com.spring.validator.RegisterFormValidator;

@Controller
@SessionAttributes("userInSession")
public class HomeController {

	@Autowired
	HttpSession sess;
	
	@Autowired
	UserService userService;



	@RequestMapping(value = { "/", "/home" }, method = RequestMethod.GET)
	public String home() {
		return "home";
	}

	@GetMapping(value = "/registerme")
	public String processRegisterMe(Model model) {
		model.addAttribute("user", new User());
		return "registerMe";
	}

	@PostMapping(value = "/registerme")
	public String processRegisterMeForm(@ModelAttribute("user") User user, BindingResult result) {
		userService.saveUser(user);
		return "home";
	}

	@RequestMapping(value = { "/loginhtml" }, method = RequestMethod.GET)
	public String processLoginHtmlPage(Model model) {
		return "loginHTML";
	}

	@RequestMapping(value = { "/loginhtml" }, method = RequestMethod.POST)
	public String processLoginHtmlCredentials(@RequestParam(value = "name") String name,
			HttpServletRequest req, Model model) {
		String pwd = req.getParameter("password");
		User usr = new User();
		usr.setName(name);
		usr.setPassword(pwd);

		if (userService.findUser(usr)) {
			model.addAttribute("userInSession", name);
			return "adminHome";

		}

		return "loginHTML";
	}

	
	@GetMapping(value = "/logout")
	public String processLogout() {
		return "logout";
	}
}
